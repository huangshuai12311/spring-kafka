/**
 * Package for kafka configuration
 */
@org.springframework.lang.NonNullApi
package org.springframework.kafka.config;
